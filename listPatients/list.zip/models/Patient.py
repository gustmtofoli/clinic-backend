class Patient:
    def __init__(self):
        self.name = ""
        self.lasName = ""
