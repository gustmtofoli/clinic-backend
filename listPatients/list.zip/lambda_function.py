import json
from aws.rds.PatientPostgres import PatientPostgres

def lambda_handler(event, context):
    db = PatientPostgres()
    _, _ = db.connect()

    patients = db.selectAll()
    print(patients)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }



